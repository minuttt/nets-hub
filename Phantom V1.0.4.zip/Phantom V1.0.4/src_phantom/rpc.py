from pypresence import Presence
import time
import json
from src_phantom.phantomfrontend import *

try:
    CONFIG = json.load(open("../Main Directory/Config.json", "r"))
except FileNotFoundError:
    print("There is no 'Config.json'")
    exit()

client_id = 1016375632646647950
RPC = Presence(client_id)
RPC.connect()


def updateStatus(status):
    if CONFIG[""] == True:
        RPC.update(
            buttons=
            [
                {
                    "label": "Phantom Website",
                    "url": "http://teamphantom.online/"
                },
                {
                    "label": "Aurora Server",
                    "url": "not done yet"
                }
            ],
            large_image="logo",
            large_text="Phantom",
            details=status,
            start=time.time()
        )
